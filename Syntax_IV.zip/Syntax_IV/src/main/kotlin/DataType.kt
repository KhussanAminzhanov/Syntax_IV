sealed class DataType {
    class DoubleType(var value: Double)
    class UnitType
}